﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DistanceConverter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button_convert_Click(object sender, EventArgs e)
        {
            double distance;
            double.TryParse(distanceInput.Text, out distance);

            if(listBox_from.SelectedIndex != -1 && listBox_to.SelectedIndex != -1)
            {
                String selectedDistance = listBox_from.SelectedItem.ToString();
                String outputDistance = listBox_to.SelectedItem.ToString();


                if (selectedDistance == outputDistance)
                {
                    output_label.Text = distance.ToString();
                }
                else
                {
                    switch(selectedDistance)
                    {
                        case "Inches":
                            if (outputDistance == "Feet")
                            {
                                double result = distance / 12;
                                output_label.Text = result.ToString();
                            } else
                            {
                                double result = distance / 36;
                                output_label.Text = result.ToString();
                            }
                            break;

                        case "Feet":
                            if (outputDistance == "Inches")
                            {
                                double result = distance * 12;
                                output_label.Text = result.ToString();
                            }
                            else
                            {
                                double result = distance / 3;
                                output_label.Text = result.ToString();
                            }
                            break;

                        case "Yards":
                            if (outputDistance == "Inches")
                            {
                                double result = distance * 36;
                                output_label.Text = result.ToString();
                            }
                            else
                            {
                                double result = distance * 3;
                                output_label.Text = result.ToString();
                            }
                            break;
                    }
                }


            } else
            {
                MessageBox.Show("Please input a number and select options below!");
            }


        }
    }
}
