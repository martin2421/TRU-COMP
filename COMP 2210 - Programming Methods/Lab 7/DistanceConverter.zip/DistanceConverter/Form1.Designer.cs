﻿namespace DistanceConverter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.distanceInput = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.output_label = new System.Windows.Forms.Label();
            this.listBox_from = new System.Windows.Forms.ListBox();
            this.listBox_to = new System.Windows.Forms.ListBox();
            this.button_convert = new System.Windows.Forms.Button();
            this.button_exit = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter a distance to convert:";
            // 
            // distanceInput
            // 
            this.distanceInput.Location = new System.Drawing.Point(184, 37);
            this.distanceInput.Name = "distanceInput";
            this.distanceInput.Size = new System.Drawing.Size(141, 20);
            this.distanceInput.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.listBox_from);
            this.groupBox1.Location = new System.Drawing.Point(43, 88);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(135, 108);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "From";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.listBox_to);
            this.groupBox2.Location = new System.Drawing.Point(190, 88);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(135, 108);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "To";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(74, 225);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Converted Distance:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // output_label
            // 
            this.output_label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.output_label.Location = new System.Drawing.Point(190, 220);
            this.output_label.Name = "output_label";
            this.output_label.Size = new System.Drawing.Size(100, 23);
            this.output_label.TabIndex = 5;
            this.output_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // listBox_from
            // 
            this.listBox_from.FormattingEnabled = true;
            this.listBox_from.Items.AddRange(new object[] {
            "Inches",
            "Feet",
            "Yards"});
            this.listBox_from.Location = new System.Drawing.Point(6, 32);
            this.listBox_from.Name = "listBox_from";
            this.listBox_from.Size = new System.Drawing.Size(123, 43);
            this.listBox_from.TabIndex = 0;
            // 
            // listBox_to
            // 
            this.listBox_to.FormattingEnabled = true;
            this.listBox_to.Items.AddRange(new object[] {
            "Inches",
            "Feet",
            "Yards"});
            this.listBox_to.Location = new System.Drawing.Point(6, 32);
            this.listBox_to.Name = "listBox_to";
            this.listBox_to.Size = new System.Drawing.Size(123, 43);
            this.listBox_to.TabIndex = 1;
            // 
            // button_convert
            // 
            this.button_convert.Location = new System.Drawing.Point(43, 267);
            this.button_convert.Name = "button_convert";
            this.button_convert.Size = new System.Drawing.Size(135, 23);
            this.button_convert.TabIndex = 6;
            this.button_convert.Text = "Convert";
            this.button_convert.UseVisualStyleBackColor = true;
            this.button_convert.Click += new System.EventHandler(this.button_convert_Click);
            // 
            // button_exit
            // 
            this.button_exit.Location = new System.Drawing.Point(190, 267);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(135, 23);
            this.button_exit.TabIndex = 7;
            this.button_exit.Text = "Exit";
            this.button_exit.UseVisualStyleBackColor = true;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(364, 315);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.button_convert);
            this.Controls.Add(this.output_label);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.distanceInput);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox distanceInput;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label output_label;
        private System.Windows.Forms.ListBox listBox_from;
        private System.Windows.Forms.ListBox listBox_to;
        private System.Windows.Forms.Button button_convert;
        private System.Windows.Forms.Button button_exit;
    }
}

