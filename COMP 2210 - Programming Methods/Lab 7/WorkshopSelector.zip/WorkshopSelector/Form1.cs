namespace WorkshopSelector
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button_calculate_Click(object sender, EventArgs e)
        {
            decimal registration = 0;
            decimal lodging = 0;
            decimal total = 0;
            int days = 0;

            if (workshopListBox.SelectedIndex != -1 && locationListBox.SelectedIndex != -1)
            {
                String workshop = workshopListBox.SelectedItem.ToString();
                String location = locationListBox.SelectedItem.ToString();

                switch (workshop)
                {
                    case "Handling Stress":
                        registration = 1000;
                        days = 3;
                        break;

                    case "Time Management":
                        registration = 800;
                        days = 3;
                        break;

                    case "Supervision Skills":
                        registration = 1500;
                        days = 3;
                        break;

                    case "Negotiation":
                        registration = 1300;
                        days = 5;
                        break;

                    case "How to Interview":
                        registration = 500;
                        days = 1;
                        break;
                }


                switch (location)
                {
                    case "Austin":
                        lodging = 150 * days;
                        break;

                    case "Chicago":
                        lodging = 225 * days;
                        break;

                    case "Dallas":
                        lodging = 175 * days;
                        break;

                    case "Orlando":
                        lodging = 300 * days;
                        break;

                    case "Phoenix":
                        lodging = 175 * days;
                        break;

                    case "Raleigh":
                        lodging = 150 * days;
                        break;
                }

                total = registration + lodging;

                registrationLabel.Text = "$ " + String.Format("{0:n}", registration);
                lodgingLabel.Text = "$ " + String.Format("{0:n}", lodging);
                totalLabel.Text = "$ " + String.Format("{0:n}", total);

            }
            else
            {
                MessageBox.Show("Please select options below!");
            }

        }
    }
}