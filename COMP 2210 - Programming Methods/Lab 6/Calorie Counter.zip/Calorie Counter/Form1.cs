namespace Calorie_Counter
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox_banana_Click(object sender, EventArgs e)
        {
            int result = int.Parse(label_calculation.Text);
            label_calculation.Text = Convert.ToString(result + 115);
        }

        private void label_115_Click(object sender, EventArgs e)
        {
            int result = int.Parse(label_calculation.Text);
            label_calculation.Text = Convert.ToString(result + 115);
        }

        private void pictureBox_apple_Click(object sender, EventArgs e)
        {
            int result = int.Parse(label_calculation.Text);
            label_calculation.Text = Convert.ToString(result + 80);
        }

        private void label_80_Click(object sender, EventArgs e)
        {
            int result = int.Parse(label_calculation.Text);
            label_calculation.Text = Convert.ToString(result + 80);
        }

        private void pictureBox_orange_Click(object sender, EventArgs e)
        {
            int result = int.Parse(label_calculation.Text);
            label_calculation.Text = Convert.ToString(result + 90);
        }

        private void label_90_Click(object sender, EventArgs e)
        {
            int result = int.Parse(label_calculation.Text);
            label_calculation.Text = Convert.ToString(result + 90);
        }

        private void pictureBox_pear_Click(object sender, EventArgs e)
        {
            int result = int.Parse(label_calculation.Text);
            label_calculation.Text = Convert.ToString(result + 120);
        }

        private void label_120_Click(object sender, EventArgs e)
        {
            int result = int.Parse(label_calculation.Text);
            label_calculation.Text = Convert.ToString(result + 120);
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button_reset_Click(object sender, EventArgs e)
        {
            label_calculation.Text = "0";
        }
    }
}