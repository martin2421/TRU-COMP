﻿namespace Calorie_Counter
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label_totalCalories = new System.Windows.Forms.Label();
            this.label_calculation = new System.Windows.Forms.Label();
            this.button_reset = new System.Windows.Forms.Button();
            this.button_exit = new System.Windows.Forms.Button();
            this.pictureBox_banana = new System.Windows.Forms.PictureBox();
            this.pictureBox_apple = new System.Windows.Forms.PictureBox();
            this.pictureBox_orange = new System.Windows.Forms.PictureBox();
            this.pictureBox_pear = new System.Windows.Forms.PictureBox();
            this.label_115 = new System.Windows.Forms.Label();
            this.label_80 = new System.Windows.Forms.Label();
            this.label_90 = new System.Windows.Forms.Label();
            this.label_120 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_banana)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_apple)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_orange)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_pear)).BeginInit();
            this.SuspendLayout();
            // 
            // label_totalCalories
            // 
            this.label_totalCalories.AutoSize = true;
            this.label_totalCalories.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_totalCalories.Location = new System.Drawing.Point(712, 65);
            this.label_totalCalories.Name = "label_totalCalories";
            this.label_totalCalories.Size = new System.Drawing.Size(177, 36);
            this.label_totalCalories.TabIndex = 0;
            this.label_totalCalories.Text = "Total Calories";
            // 
            // label_calculation
            // 
            this.label_calculation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_calculation.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label_calculation.Location = new System.Drawing.Point(694, 116);
            this.label_calculation.Name = "label_calculation";
            this.label_calculation.Size = new System.Drawing.Size(218, 38);
            this.label_calculation.TabIndex = 1;
            this.label_calculation.Text = "0";
            this.label_calculation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button_reset
            // 
            this.button_reset.Location = new System.Drawing.Point(712, 410);
            this.button_reset.Name = "button_reset";
            this.button_reset.Size = new System.Drawing.Size(177, 41);
            this.button_reset.TabIndex = 2;
            this.button_reset.Text = "Reset";
            this.button_reset.UseVisualStyleBackColor = true;
            this.button_reset.Click += new System.EventHandler(this.button_reset_Click);
            // 
            // button_exit
            // 
            this.button_exit.Location = new System.Drawing.Point(712, 474);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(177, 41);
            this.button_exit.TabIndex = 3;
            this.button_exit.Text = "Exit";
            this.button_exit.UseVisualStyleBackColor = true;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // pictureBox_banana
            // 
            this.pictureBox_banana.Image = global::Calorie_Counter.Properties.Resources.banana;
            this.pictureBox_banana.Location = new System.Drawing.Point(27, 65);
            this.pictureBox_banana.Name = "pictureBox_banana";
            this.pictureBox_banana.Size = new System.Drawing.Size(230, 195);
            this.pictureBox_banana.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_banana.TabIndex = 4;
            this.pictureBox_banana.TabStop = false;
            this.pictureBox_banana.Click += new System.EventHandler(this.pictureBox_banana_Click);
            // 
            // pictureBox_apple
            // 
            this.pictureBox_apple.Image = global::Calorie_Counter.Properties.Resources.apple;
            this.pictureBox_apple.Location = new System.Drawing.Point(347, 65);
            this.pictureBox_apple.Name = "pictureBox_apple";
            this.pictureBox_apple.Size = new System.Drawing.Size(230, 195);
            this.pictureBox_apple.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_apple.TabIndex = 5;
            this.pictureBox_apple.TabStop = false;
            this.pictureBox_apple.Click += new System.EventHandler(this.pictureBox_apple_Click);
            // 
            // pictureBox_orange
            // 
            this.pictureBox_orange.Image = global::Calorie_Counter.Properties.Resources.orange;
            this.pictureBox_orange.Location = new System.Drawing.Point(27, 320);
            this.pictureBox_orange.Name = "pictureBox_orange";
            this.pictureBox_orange.Size = new System.Drawing.Size(230, 195);
            this.pictureBox_orange.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_orange.TabIndex = 6;
            this.pictureBox_orange.TabStop = false;
            this.pictureBox_orange.Click += new System.EventHandler(this.pictureBox_orange_Click);
            // 
            // pictureBox_pear
            // 
            this.pictureBox_pear.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_pear.Image")));
            this.pictureBox_pear.Location = new System.Drawing.Point(347, 320);
            this.pictureBox_pear.Name = "pictureBox_pear";
            this.pictureBox_pear.Size = new System.Drawing.Size(230, 195);
            this.pictureBox_pear.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_pear.TabIndex = 7;
            this.pictureBox_pear.TabStop = false;
            this.pictureBox_pear.Click += new System.EventHandler(this.pictureBox_pear_Click);
            // 
            // label_115
            // 
            this.label_115.AutoSize = true;
            this.label_115.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_115.Location = new System.Drawing.Point(52, 263);
            this.label_115.Name = "label_115";
            this.label_115.Size = new System.Drawing.Size(162, 36);
            this.label_115.TabIndex = 8;
            this.label_115.Text = "115 Calories";
            this.label_115.Click += new System.EventHandler(this.label_115_Click);
            // 
            // label_80
            // 
            this.label_80.AutoSize = true;
            this.label_80.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_80.Location = new System.Drawing.Point(389, 263);
            this.label_80.Name = "label_80";
            this.label_80.Size = new System.Drawing.Size(147, 36);
            this.label_80.TabIndex = 9;
            this.label_80.Text = "80 Calories";
            this.label_80.Click += new System.EventHandler(this.label_80_Click);
            // 
            // label_90
            // 
            this.label_90.AutoSize = true;
            this.label_90.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_90.Location = new System.Drawing.Point(67, 518);
            this.label_90.Name = "label_90";
            this.label_90.Size = new System.Drawing.Size(147, 36);
            this.label_90.TabIndex = 10;
            this.label_90.Text = "90 Calories";
            this.label_90.Click += new System.EventHandler(this.label_90_Click);
            // 
            // label_120
            // 
            this.label_120.AutoSize = true;
            this.label_120.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_120.Location = new System.Drawing.Point(389, 518);
            this.label_120.Name = "label_120";
            this.label_120.Size = new System.Drawing.Size(162, 36);
            this.label_120.TabIndex = 11;
            this.label_120.Text = "120 Calories";
            this.label_120.Click += new System.EventHandler(this.label_120_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(942, 588);
            this.Controls.Add(this.label_120);
            this.Controls.Add(this.label_90);
            this.Controls.Add(this.label_80);
            this.Controls.Add(this.label_115);
            this.Controls.Add(this.pictureBox_pear);
            this.Controls.Add(this.pictureBox_orange);
            this.Controls.Add(this.pictureBox_apple);
            this.Controls.Add(this.pictureBox_banana);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.button_reset);
            this.Controls.Add(this.label_calculation);
            this.Controls.Add(this.label_totalCalories);
            this.Name = "Form1";
            this.Text = "Calorie Counter";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_banana)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_apple)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_orange)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_pear)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label_totalCalories;
        private Label label_calculation;
        private Button button_reset;
        private Button button_exit;
        private PictureBox pictureBox_banana;
        private PictureBox pictureBox_apple;
        private PictureBox pictureBox_orange;
        private PictureBox pictureBox_pear;
        private Label label_115;
        private Label label_80;
        private Label label_90;
        private Label label_120;
    }
}