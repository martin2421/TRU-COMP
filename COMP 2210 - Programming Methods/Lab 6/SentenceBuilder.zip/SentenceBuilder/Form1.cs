namespace SentenceBuilder
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            label_output.Text += "A";
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            label_output.Text += "An";
        }

        private void button19_Click(object sender, EventArgs e)
        {
            label_output.Text += "spoke to";
        }

        private void button_a2_Click(object sender, EventArgs e)
        {
            label_output.Text += "a";
        }

        private void button_an2_Click(object sender, EventArgs e)
        {
            label_output.Text += "an";
        }

        private void button_The_Click(object sender, EventArgs e)
        {
            label_output.Text += "The";
        }

        private void button_the2_Click(object sender, EventArgs e)
        {
            label_output.Text += "the";
        }

        private void button_man_Click(object sender, EventArgs e)
        {
            label_output.Text += "man";
        }

        private void button_woman_Click(object sender, EventArgs e)
        {
            label_output.Text += "woman";
        }

        private void button_dog_Click(object sender, EventArgs e)
        {
            label_output.Text += "dog";
        }

        private void button_cat_Click(object sender, EventArgs e)
        {
            label_output.Text += "cat";
        }

        private void button_car_Click(object sender, EventArgs e)
        {
            label_output.Text += "car";
        }

        private void button_bicycle_Click(object sender, EventArgs e)
        {
            label_output.Text += "bicycle";
        }

        private void button_beautiful_Click(object sender, EventArgs e)
        {
            label_output.Text += "beautiful";
        }

        private void button_big_Click(object sender, EventArgs e)
        {
            label_output.Text += "big";
        }

        private void button_small_Click(object sender, EventArgs e)
        {
            label_output.Text += "small";
        }

        private void button_strange_Click(object sender, EventArgs e)
        {
            label_output.Text += "strange";
        }

        private void button_looked_at_Click(object sender, EventArgs e)
        {
            label_output.Text += "looked at";
        }

        private void button_rode_Click(object sender, EventArgs e)
        {
            label_output.Text += "rode";
        }

        private void button_laughed_at_Click(object sender, EventArgs e)
        {
            label_output.Text += "laughed at";
        }

        private void button_drove_Click(object sender, EventArgs e)
        {
            label_output.Text += "drove";
        }

        private void button_space_Click(object sender, EventArgs e)
        {
            label_output.Text += " ";
        }

        private void button_dot_Click(object sender, EventArgs e)
        {
            label_output.Text += ".";
        }

        private void button_exclamation_Click(object sender, EventArgs e)
        {
            label_output.Text += "!";
        }

        private void button_clear_Click(object sender, EventArgs e)
        {
            label_output.Text = "";
        }

        private void label_output_Click(object sender, EventArgs e)
        {

        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}