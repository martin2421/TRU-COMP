﻿namespace SentenceBuilder
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_a2 = new System.Windows.Forms.Button();
            this.button_A = new System.Windows.Forms.Button();
            this.button_An = new System.Windows.Forms.Button();
            this.button_an2 = new System.Windows.Forms.Button();
            this.button_The = new System.Windows.Forms.Button();
            this.button_the2 = new System.Windows.Forms.Button();
            this.button_man = new System.Windows.Forms.Button();
            this.button_woman = new System.Windows.Forms.Button();
            this.button_dog = new System.Windows.Forms.Button();
            this.button_cat = new System.Windows.Forms.Button();
            this.button_car = new System.Windows.Forms.Button();
            this.button_bicycle = new System.Windows.Forms.Button();
            this.button_beautiful = new System.Windows.Forms.Button();
            this.button_big = new System.Windows.Forms.Button();
            this.button_small = new System.Windows.Forms.Button();
            this.button_strange = new System.Windows.Forms.Button();
            this.button_looked_at = new System.Windows.Forms.Button();
            this.button_rode = new System.Windows.Forms.Button();
            this.button_spoke_to = new System.Windows.Forms.Button();
            this.button_laughed_at = new System.Windows.Forms.Button();
            this.button_drove = new System.Windows.Forms.Button();
            this.button_space = new System.Windows.Forms.Button();
            this.button_dot = new System.Windows.Forms.Button();
            this.button_exclamation = new System.Windows.Forms.Button();
            this.button_clear = new System.Windows.Forms.Button();
            this.button_exit = new System.Windows.Forms.Button();
            this.label_output = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button_a2
            // 
            this.button_a2.Location = new System.Drawing.Point(205, 90);
            this.button_a2.Name = "button_a2";
            this.button_a2.Size = new System.Drawing.Size(63, 34);
            this.button_a2.TabIndex = 1;
            this.button_a2.Text = "a";
            this.button_a2.UseVisualStyleBackColor = true;
            this.button_a2.Click += new System.EventHandler(this.button_a2_Click);
            // 
            // button_A
            // 
            this.button_A.Location = new System.Drawing.Point(125, 90);
            this.button_A.Name = "button_A";
            this.button_A.Size = new System.Drawing.Size(63, 34);
            this.button_A.TabIndex = 2;
            this.button_A.Text = "A";
            this.button_A.UseVisualStyleBackColor = true;
            this.button_A.Click += new System.EventHandler(this.button3_Click);
            // 
            // button_An
            // 
            this.button_An.Location = new System.Drawing.Point(285, 90);
            this.button_An.Name = "button_An";
            this.button_An.Size = new System.Drawing.Size(63, 34);
            this.button_An.TabIndex = 3;
            this.button_An.Text = "An";
            this.button_An.UseVisualStyleBackColor = true;
            this.button_An.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button_an2
            // 
            this.button_an2.Location = new System.Drawing.Point(368, 90);
            this.button_an2.Name = "button_an2";
            this.button_an2.Size = new System.Drawing.Size(63, 34);
            this.button_an2.TabIndex = 4;
            this.button_an2.Text = "an";
            this.button_an2.UseVisualStyleBackColor = true;
            this.button_an2.Click += new System.EventHandler(this.button_an2_Click);
            // 
            // button_The
            // 
            this.button_The.Location = new System.Drawing.Point(452, 90);
            this.button_The.Name = "button_The";
            this.button_The.Size = new System.Drawing.Size(63, 34);
            this.button_The.TabIndex = 5;
            this.button_The.Text = "The";
            this.button_The.UseVisualStyleBackColor = true;
            this.button_The.Click += new System.EventHandler(this.button_The_Click);
            // 
            // button_the2
            // 
            this.button_the2.Location = new System.Drawing.Point(542, 90);
            this.button_the2.Name = "button_the2";
            this.button_the2.Size = new System.Drawing.Size(63, 34);
            this.button_the2.TabIndex = 6;
            this.button_the2.Text = "the";
            this.button_the2.UseVisualStyleBackColor = true;
            this.button_the2.Click += new System.EventHandler(this.button_the2_Click);
            // 
            // button_man
            // 
            this.button_man.Location = new System.Drawing.Point(105, 146);
            this.button_man.Name = "button_man";
            this.button_man.Size = new System.Drawing.Size(63, 34);
            this.button_man.TabIndex = 7;
            this.button_man.Text = "man";
            this.button_man.UseVisualStyleBackColor = true;
            this.button_man.Click += new System.EventHandler(this.button_man_Click);
            // 
            // button_woman
            // 
            this.button_woman.Location = new System.Drawing.Point(187, 146);
            this.button_woman.Name = "button_woman";
            this.button_woman.Size = new System.Drawing.Size(81, 34);
            this.button_woman.TabIndex = 8;
            this.button_woman.Text = "woman";
            this.button_woman.UseVisualStyleBackColor = true;
            this.button_woman.Click += new System.EventHandler(this.button_woman_Click);
            // 
            // button_dog
            // 
            this.button_dog.Location = new System.Drawing.Point(285, 146);
            this.button_dog.Name = "button_dog";
            this.button_dog.Size = new System.Drawing.Size(63, 34);
            this.button_dog.TabIndex = 9;
            this.button_dog.Text = "dog";
            this.button_dog.UseVisualStyleBackColor = true;
            this.button_dog.Click += new System.EventHandler(this.button_dog_Click);
            // 
            // button_cat
            // 
            this.button_cat.Location = new System.Drawing.Point(368, 146);
            this.button_cat.Name = "button_cat";
            this.button_cat.Size = new System.Drawing.Size(63, 34);
            this.button_cat.TabIndex = 10;
            this.button_cat.Text = "cat";
            this.button_cat.UseVisualStyleBackColor = true;
            this.button_cat.Click += new System.EventHandler(this.button_cat_Click);
            // 
            // button_car
            // 
            this.button_car.Location = new System.Drawing.Point(452, 146);
            this.button_car.Name = "button_car";
            this.button_car.Size = new System.Drawing.Size(63, 34);
            this.button_car.TabIndex = 11;
            this.button_car.Text = "car";
            this.button_car.UseVisualStyleBackColor = true;
            this.button_car.Click += new System.EventHandler(this.button_car_Click);
            // 
            // button_bicycle
            // 
            this.button_bicycle.Location = new System.Drawing.Point(542, 146);
            this.button_bicycle.Name = "button_bicycle";
            this.button_bicycle.Size = new System.Drawing.Size(81, 34);
            this.button_bicycle.TabIndex = 12;
            this.button_bicycle.Text = "bicycle";
            this.button_bicycle.UseVisualStyleBackColor = true;
            this.button_bicycle.Click += new System.EventHandler(this.button_bicycle_Click);
            // 
            // button_beautiful
            // 
            this.button_beautiful.Location = new System.Drawing.Point(125, 208);
            this.button_beautiful.Name = "button_beautiful";
            this.button_beautiful.Size = new System.Drawing.Size(91, 34);
            this.button_beautiful.TabIndex = 13;
            this.button_beautiful.Text = "beautiful";
            this.button_beautiful.UseVisualStyleBackColor = true;
            this.button_beautiful.Click += new System.EventHandler(this.button_beautiful_Click);
            // 
            // button_big
            // 
            this.button_big.Location = new System.Drawing.Point(244, 208);
            this.button_big.Name = "button_big";
            this.button_big.Size = new System.Drawing.Size(63, 34);
            this.button_big.TabIndex = 14;
            this.button_big.Text = "big";
            this.button_big.UseVisualStyleBackColor = true;
            this.button_big.Click += new System.EventHandler(this.button_big_Click);
            // 
            // button_small
            // 
            this.button_small.Location = new System.Drawing.Point(333, 208);
            this.button_small.Name = "button_small";
            this.button_small.Size = new System.Drawing.Size(63, 34);
            this.button_small.TabIndex = 15;
            this.button_small.Text = "small";
            this.button_small.UseVisualStyleBackColor = true;
            this.button_small.Click += new System.EventHandler(this.button_small_Click);
            // 
            // button_strange
            // 
            this.button_strange.Location = new System.Drawing.Point(424, 208);
            this.button_strange.Name = "button_strange";
            this.button_strange.Size = new System.Drawing.Size(91, 34);
            this.button_strange.TabIndex = 16;
            this.button_strange.Text = "strange";
            this.button_strange.UseVisualStyleBackColor = true;
            this.button_strange.Click += new System.EventHandler(this.button_strange_Click);
            // 
            // button_looked_at
            // 
            this.button_looked_at.Location = new System.Drawing.Point(75, 271);
            this.button_looked_at.Name = "button_looked_at";
            this.button_looked_at.Size = new System.Drawing.Size(111, 34);
            this.button_looked_at.TabIndex = 17;
            this.button_looked_at.Text = "looked at";
            this.button_looked_at.UseVisualStyleBackColor = true;
            this.button_looked_at.Click += new System.EventHandler(this.button_looked_at_Click);
            // 
            // button_rode
            // 
            this.button_rode.Location = new System.Drawing.Point(205, 271);
            this.button_rode.Name = "button_rode";
            this.button_rode.Size = new System.Drawing.Size(63, 34);
            this.button_rode.TabIndex = 18;
            this.button_rode.Text = "rode";
            this.button_rode.UseVisualStyleBackColor = true;
            this.button_rode.Click += new System.EventHandler(this.button_rode_Click);
            // 
            // button_spoke_to
            // 
            this.button_spoke_to.Location = new System.Drawing.Point(285, 271);
            this.button_spoke_to.Name = "button_spoke_to";
            this.button_spoke_to.Size = new System.Drawing.Size(111, 34);
            this.button_spoke_to.TabIndex = 19;
            this.button_spoke_to.Text = "spoke to";
            this.button_spoke_to.UseVisualStyleBackColor = true;
            this.button_spoke_to.Click += new System.EventHandler(this.button19_Click);
            // 
            // button_laughed_at
            // 
            this.button_laughed_at.Location = new System.Drawing.Point(414, 271);
            this.button_laughed_at.Name = "button_laughed_at";
            this.button_laughed_at.Size = new System.Drawing.Size(111, 34);
            this.button_laughed_at.TabIndex = 20;
            this.button_laughed_at.Text = "laughed at";
            this.button_laughed_at.UseVisualStyleBackColor = true;
            this.button_laughed_at.Click += new System.EventHandler(this.button_laughed_at_Click);
            // 
            // button_drove
            // 
            this.button_drove.Location = new System.Drawing.Point(542, 271);
            this.button_drove.Name = "button_drove";
            this.button_drove.Size = new System.Drawing.Size(72, 34);
            this.button_drove.TabIndex = 21;
            this.button_drove.Text = "drove";
            this.button_drove.UseVisualStyleBackColor = true;
            this.button_drove.Click += new System.EventHandler(this.button_drove_Click);
            // 
            // button_space
            // 
            this.button_space.Location = new System.Drawing.Point(177, 335);
            this.button_space.Name = "button_space";
            this.button_space.Size = new System.Drawing.Size(111, 34);
            this.button_space.TabIndex = 22;
            this.button_space.Text = "(Space)";
            this.button_space.UseVisualStyleBackColor = true;
            this.button_space.Click += new System.EventHandler(this.button_space_Click);
            // 
            // button_dot
            // 
            this.button_dot.Location = new System.Drawing.Point(309, 335);
            this.button_dot.Name = "button_dot";
            this.button_dot.Size = new System.Drawing.Size(63, 34);
            this.button_dot.TabIndex = 23;
            this.button_dot.Text = ".";
            this.button_dot.UseVisualStyleBackColor = true;
            this.button_dot.Click += new System.EventHandler(this.button_dot_Click);
            // 
            // button_exclamation
            // 
            this.button_exclamation.Location = new System.Drawing.Point(392, 335);
            this.button_exclamation.Name = "button_exclamation";
            this.button_exclamation.Size = new System.Drawing.Size(63, 34);
            this.button_exclamation.TabIndex = 24;
            this.button_exclamation.Text = "!";
            this.button_exclamation.UseVisualStyleBackColor = true;
            this.button_exclamation.Click += new System.EventHandler(this.button_exclamation_Click);
            // 
            // button_clear
            // 
            this.button_clear.Location = new System.Drawing.Point(205, 537);
            this.button_clear.Name = "button_clear";
            this.button_clear.Size = new System.Drawing.Size(112, 34);
            this.button_clear.TabIndex = 25;
            this.button_clear.Text = "Clear";
            this.button_clear.UseVisualStyleBackColor = true;
            this.button_clear.Click += new System.EventHandler(this.button_clear_Click);
            // 
            // button_exit
            // 
            this.button_exit.Location = new System.Drawing.Point(343, 537);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(112, 34);
            this.button_exit.TabIndex = 26;
            this.button_exit.Text = "Exit";
            this.button_exit.UseVisualStyleBackColor = true;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // label_output
            // 
            this.label_output.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_output.LiveSetting = System.Windows.Forms.Automation.AutomationLiveSetting.Polite;
            this.label_output.Location = new System.Drawing.Point(58, 443);
            this.label_output.Name = "label_output";
            this.label_output.Size = new System.Drawing.Size(600, 25);
            this.label_output.TabIndex = 27;
            this.label_output.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_output.Click += new System.EventHandler(this.label_output_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(739, 643);
            this.Controls.Add(this.label_output);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.button_clear);
            this.Controls.Add(this.button_exclamation);
            this.Controls.Add(this.button_dot);
            this.Controls.Add(this.button_space);
            this.Controls.Add(this.button_drove);
            this.Controls.Add(this.button_laughed_at);
            this.Controls.Add(this.button_spoke_to);
            this.Controls.Add(this.button_rode);
            this.Controls.Add(this.button_looked_at);
            this.Controls.Add(this.button_strange);
            this.Controls.Add(this.button_small);
            this.Controls.Add(this.button_big);
            this.Controls.Add(this.button_beautiful);
            this.Controls.Add(this.button_bicycle);
            this.Controls.Add(this.button_car);
            this.Controls.Add(this.button_cat);
            this.Controls.Add(this.button_dog);
            this.Controls.Add(this.button_woman);
            this.Controls.Add(this.button_man);
            this.Controls.Add(this.button_the2);
            this.Controls.Add(this.button_The);
            this.Controls.Add(this.button_an2);
            this.Controls.Add(this.button_An);
            this.Controls.Add(this.button_A);
            this.Controls.Add(this.button_a2);
            this.Name = "Form1";
            this.Text = "Sentence Builder";
            this.ResumeLayout(false);

        }

        #endregion

        private Button button_a2;
        private Button button_A;
        private Button button_An;
        private Button button_an2;
        private Button button_The;
        private Button button_the2;
        private Button button_man;
        private Button button_woman;
        private Button button_dog;
        private Button button_cat;
        private Button button_car;
        private Button button_bicycle;
        private Button button_beautiful;
        private Button button_big;
        private Button button_small;
        private Button button_strange;
        private Button button_looked_at;
        private Button button_rode;
        private Button button_spoke_to;
        private Button button_laughed_at;
        private Button button_drove;
        private Button button_space;
        private Button button_dot;
        private Button button_exclamation;
        private Button button_clear;
        private Button button_exit;
        private Label label_output;
    }
}