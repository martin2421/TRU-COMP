﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TelephoneFormat
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void formatButton_Click(object sender, EventArgs e)
        {
            string number = numberTextBox.Text.Trim();

            if (IsValidNumber(number))
            {
                TelephoneFormat(ref number);
                MessageBox.Show("Telephone Number: " + number);
            }
            else
            {
                MessageBox.Show("Invalid number. Try again.");
            }
        }

        private bool IsValidNumber(String str)
        {
            const int LENGTH = 10;
            bool valid = true;

            if(str.Length == LENGTH)
            {
                foreach(char c in str)
                {
                    if (!char.IsDigit(c))
                    {
                        valid = false;
                    }
                }
            }
            else
            {
                valid = false;
            }
            return valid;
        }

        private void TelephoneFormat(ref string str)
        {
            str = str.Insert(0, "(");
            str = str.Insert(4, ")");
            str = str.Insert(8, "-");
        }

    }
}
