﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PasswordValidation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void checkPasswordButton_Click(object sender, EventArgs e)
        {
            const int LENGTH = 8;

            string password = passwordTextBox.Text;

            if(password.Length >= LENGTH && NumberUppercase(password) >= 1 && 
                NumberLowerCase(password) >= 1 && NumberDigits(password) >= 1)
            {
                MessageBox.Show("The password is VALID!");
            } 
            else
            {
                MessageBox.Show("Requirements not met. Try again.");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private int NumberUppercase(String str)
        {
            int uppercases = 0;

            foreach (char c in str)
            {
                if(char.IsUpper(c))
                {
                    uppercases++;
                }
            }
            return uppercases;
        }

        private int NumberLowerCase(String str)
        {
            int lowercases = 0;

            foreach(char c in str)
            {
                if(char.IsLower(c))
                {
                    lowercases++;
                }
            }
            return lowercases;
        }

        private int NumberDigits(String str)
        {
            int digits = 0;

            foreach(char c in str)
            {
                if(char.IsDigit(c))
                {
                    digits++;
                }
            }
            return digits;
        }

    }
}
