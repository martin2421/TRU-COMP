﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChangeDollarGame
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            // const variables containing the multipliers
            const int PENNIES = 1;
            const int NICKELS = 5;
            const int DIMES = 10;
            const int QUARTERS = 25;

            // variables
            int penniesInput, nickelsInput, dimesInput, quartersInput;
            int total = 0;

            // tries to parse content in text box, outputing to their corresponding
            // input variable
            if(int.TryParse(penniesTextBox.Text, out penniesInput) &&
                int.TryParse(nickelsTextBox.Text, out nickelsInput) &&
                int.TryParse(dimesTextBox.Text, out dimesInput) &&
                int.TryParse(quartersTextBox.Text, out quartersInput))
            {
                // adds up the numbers input by user
                total = (penniesInput * PENNIES) + 
                    (nickelsInput * NICKELS) + 
                    (dimesInput * DIMES) + 
                    (quartersInput * QUARTERS);

                // checks if change adds to $1.00
                if(total == 100)
                {
                    MessageBox.Show("Correct! Your change adds to $1.00.");
                }
                else
                {
                    MessageBox.Show("Your change doesn't add to $1.00. Try again...");
                }
            }
            // indicates user has input wrong data types
            else
            {
                MessageBox.Show("Wrong input. Make sure all fields contain INTEGERS only!");
            }

        }
        // closes program
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
