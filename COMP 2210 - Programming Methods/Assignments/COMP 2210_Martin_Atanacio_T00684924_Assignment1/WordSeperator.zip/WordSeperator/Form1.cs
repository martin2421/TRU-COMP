﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WordSeperator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void testButton_Click(object sender, EventArgs e)
        {
            string result = ""; // variable to store output sentence
            
            foreach(char c in inputTextBox.Text) // iterates through each character in string
            {
                if (Char.IsUpper(c)) // checks if char is uppercase, and makes it a lowercase
                {
                    result += " " + Char.ToLower(c);
                }
                else // if it's lowercase, add it to the string
                {
                    result += c;
                }
            }

            // if string is empty, output error
            if(result == "")
            {
                MessageBox.Show("Input is empty. Try again...");
            }
            else
            {
                // capitalize first character of the sentence
                result = char.ToUpper(result[1]) + result.Substring(2);

                // output
                MessageBox.Show("Final Sentence:\n\n" + result);
            }

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // closes program
            this.Close();
        }
    }
}
