﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Joe_sAutomotive
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            /* 
             * calculates charges and displays them on their 
             * corresponding label
             */
            
            serviceLabel.Text = (OilLubeCharges() + FlushCharges() +
                MiscCharges() + OtherCharges()).ToString("C2");

            decimal parts = 0.00M;
            if(decimal.TryParse(partsTextBox.Text, out parts))
            {
                partsLabel.Text = parts.ToString("C2");
            }

            taxLabel.Text = TaxCharges().ToString("C2");

            totalLabel.Text = TotalCharges().ToString("C2");
        }

        // Clears elements on screen
        private void clearButton_Click(object sender, EventArgs e)
        {
            ClearOilLube();
            ClearFlushes();
            ClearMisc();
            ClearOther();
            ClearFees();
        }

        // closes program
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /*
         * User Defined Methods
         */

        // Returns total charges for oil and lube
        private decimal OilLubeCharges()
        {
            decimal total = 0.00M;

            if (oilCheckBox.Checked)
            {
                total += 26;
            }

            if (lubeCheckBox.Checked)
            {
                total += 18;
            }

            return total;
        }

        // Returns total charges for flush
        private decimal FlushCharges()
        {
            decimal total = 0.00M;

            if (radiatorCheckBox.Checked)
            {
                total += 30;
            }

            if (transmissionCheckBox.Checked)
            {
                total += 80;
            }

            return total;
        }

        // Returns total charges for misc
        private decimal MiscCharges()
        {
            decimal total = 0.00M;

            if (inspectionCheckBox.Checked)
            {
                total += 15;
            }

            if (mufflerCheckBox.Checked)
            {
                total += 100;
            }

            if (tireCheckBox.Checked)
            {
                total += 20;
            }

            return total;
        }

        // Returns total charges for other
        private decimal OtherCharges()
        {
            decimal labor = 0.00M;

            if(decimal.TryParse(laborTextBox.Text, out labor))
            {
                return labor;
            }
            else
            {
                MessageBox.Show("Wrong input. Try again...");
                return 0;
            }
        }

        // Returns total charges for tax
        private decimal TaxCharges()
        {
            const decimal TAX = 0.06M; // 6 % tax
            decimal charge = 0.00M;

            if(decimal.TryParse(partsTextBox.Text, out charge))
            {
                return charge * TAX;
            }
            else
            {
                MessageBox.Show("Wrong input. Try again...");
                return 0;
            }
        }

        // Returns total charges
        private decimal TotalCharges()
        {
            decimal parts = 0;
            decimal.TryParse(partsTextBox.Text, out parts);

            return OilLubeCharges() + FlushCharges() + MiscCharges() + 
                OtherCharges() + TaxCharges() + parts;
        }

        /* 
         * Methods to clear content and checkboxes
         */
        private void ClearOilLube()
        {
            oilCheckBox.Checked = false;
            lubeCheckBox.Checked = false;
        }
        private void ClearFlushes()
        {
            radiatorCheckBox.Checked = false;
            transmissionCheckBox.Checked = false;
        }
        private void ClearMisc()
        {
            inspectionCheckBox.Checked = false;
            mufflerCheckBox.Checked = false;
            tireCheckBox.Checked = false;
        }
        private void ClearOther()
        {
            partsTextBox.Text = "";
            laborTextBox.Text = "";
        }
        private void ClearFees()
        {
            serviceLabel.Text = "";
            partsLabel.Text = "";
            taxLabel.Text = "";
            totalLabel.Text = "";
        }
    }
}
