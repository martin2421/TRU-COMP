﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdditionTutor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            int userAnswer, num1, num2;
            String question = expLabel.Text;

            int.TryParse(question.Substring(0, 3), out num1);
            int.TryParse(question.Substring(6, 3), out num2);
            int.TryParse(answerTextBox.Text, out userAnswer);

            int answer = num1 + num2;

            if(userAnswer == answer)
            {
                MessageBox.Show("Correct!");                
            }
            else
            {
                MessageBox.Show("Try again...");
            }

        }

        private void newQuestionButton_Click(object sender, EventArgs e)
        {
            Random rand = new Random();

            int num1 = rand.Next(100, 501);
            int num2 = rand.Next(100, 501);

            expLabel.Text = num1.ToString() + " + " + num2.ToString();

        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
